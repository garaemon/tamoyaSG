$(function() {
    $(".carousel").carousel({
        interval: 10000
    });

    
    
});
